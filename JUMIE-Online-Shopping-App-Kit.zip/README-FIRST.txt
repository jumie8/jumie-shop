JUMIE ONLINE SHOPPING — INSTALLABLE APP KIT

App name: JUMIE Online Shopping
Short name: JUMIE
Brand colours: orange and white
Website: https://jumie8.github.io/jumie-shop/

WHAT THIS KIT DOES
It adds the web-app manifest, JUMIE app icons, and a basic service worker so the existing shop can be installed from a supported browser. Product inventory still loads from Supabase while online, and the Google order form still needs an internet connection.

NEXT STEPS
1. Open your GitHub repository: https://github.com/jumie8/jumie-shop/
2. Upload manifest.webmanifest and sw.js into the repository root (the same place as index.html).
3. Upload the whole icons folder, keeping both icon files inside it.
4. Open your CURRENT index.html in GitHub and edit it.
5. Follow ADD-TO-CURRENT-INDEX.txt to add the two head lines and the service-worker script.
6. Commit the change. Do not replace the current index.html with an older backup.
7. Open https://jumie8.github.io/jumie-shop/ in Chrome on Android. Open Chrome's menu and choose "Install app" or "Add to Home screen" if offered.

PLAY STORE
This kit does not publish the app to Google Play by itself. To list it on Google Play, the web app must be packaged for Android (for example, using a trusted PWA-to-Android workflow), tested, signed, and submitted through a Google Play developer account. Google Play registration has a one-time fee and may require identity verification and testing steps.
